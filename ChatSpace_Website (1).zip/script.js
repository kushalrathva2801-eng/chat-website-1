const messages = document.getElementById("messages");
const form = document.getElementById("messageForm");
const input = document.getElementById("messageInput");
const chatList = document.getElementById("chatList");
const searchInput = document.getElementById("searchInput");

const headerName = document.getElementById("headerName");
const headerStatus = document.getElementById("headerStatus");
const headerAvatar = document.getElementById("headerAvatar");

function currentTime() {
  return new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
}

function addMessage(text, type = "sent") {
  const message = document.createElement("div");
  message.className = `message ${type}`;

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  const time = document.createElement("span");
  time.textContent = type === "sent"
    ? `${currentTime()} ✓✓`
    : currentTime();

  message.appendChild(bubble);
  message.appendChild(time);
  messages.appendChild(message);
  messages.scrollTop = messages.scrollHeight;
}

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const text = input.value.trim();
  if (!text) return;

  addMessage(text, "sent");
  input.value = "";

  // Demo auto-reply. Remove this block when connecting a real backend.
  setTimeout(() => {
    addMessage("Message received 👍", "received");
  }, 700);
});

document.getElementById("emojiBtn").addEventListener("click", () => {
  input.value += " 😊";
  input.focus();
});

document.querySelectorAll(".chat-item").forEach(item => {
  item.addEventListener("click", () => {
    document.querySelectorAll(".chat-item").forEach(x => x.classList.remove("active"));
    item.classList.add("active");

    const name = item.dataset.name;
    const status = item.dataset.status;

    headerName.textContent = name;
    headerStatus.textContent = status;
    headerStatus.style.color = status === "Online" ? "#20a463" : "#7b8496";
    headerAvatar.textContent = name.charAt(0).toUpperCase();

    messages.innerHTML = `
      <div class="day">Today</div>
      <div class="message received">
        <div class="bubble">Hello! 👋</div>
        <span>${currentTime()}</span>
      </div>
    `;
  });
});

searchInput.addEventListener("input", () => {
  const query = searchInput.value.toLowerCase();

  document.querySelectorAll(".chat-item").forEach(item => {
    const name = item.dataset.name.toLowerCase();
    item.style.display = name.includes(query) ? "flex" : "none";
  });
});
